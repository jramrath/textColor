# colorText

This is a easy to use Python Library which allows you to make your Terminal outputs more colorful and therefore easyer to understand.

It currently only works with Python3

The creator is Jannik Ramrath (R2-D2-JR)

GitHub: https://github.com/R2-D2-JR/textColor